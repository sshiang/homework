/**
 *  Copyright (c) 2016, Carnegie Mellon University.  All Rights Reserved.
 */

import java.io.*;
import java.util.*;
import org.apache.lucene.index.DocsAndPositionsEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.*;
import org.apache.lucene.search.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;


/**
 *  An Indri DocVector-style interface for the Lucene termvector.
 *  There are three main data structurs:
 *  <pre>
 *    stems:      The field's vocabulary.  The 0'th entry is an empty string.
 *                It indicates a stopword.
 *    stemsFreq:  The frequency (tf) of each entry in stems.
 *    positions:  The index of the stem that occurred at this position. 
 *  </pre>
 */
public class FeatureVector {

	// relMap: answer of the ranking, docid: relevance
	public HashMap<Integer, Integer> relMap = new HashMap<Integer, Integer>(); 
	// feaMap: feature map: docid: 
	public LinkedHashMap<Integer, LinkedHashMap<String, Double> > feaMap = new LinkedHashMap<Integer, LinkedHashMap<String, Double> >();

	// get score from 
	public HashMap<Integer, Double> getTrimMap(ScoreList r, HashMap<Integer, Boolean> docMap ) throws Exception {

		HashMap<Integer, Double> scoreMap = new HashMap<Integer, Double>(); 
		for (int j=0; j<r.size(); j++) 	{
			int docid = r.getDocid(j);
			if (docMap.containsKey(docid)) {
				scoreMap.put(docid, r.getDocidScore(j));
			}
		}
		return scoreMap;

	}


	public double getOverlapScore(String[] qstems, TermVector vec) throws IOException {
		double totalScore = 0;
		int totalMatch = 0;
		for (String stem : qstems) {
			int index = -1;
			try { 
				index = vec.indexOfStem(stem);
			} catch (Exception ex) {}

			if (index != -1) {
				totalMatch++;
			}
		}
		if (qstems.length > 0) {
			totalScore = totalMatch / (double) qstems.length;
		}

		return totalScore;
	}


	public double getBM25Score(RetrievalModelBM25 model, int docid, String field, String[] qstems, TermVector vec) throws IOException {

		double totalScore=0;
		double k_1 = ((RetrievalModelBM25) model).getk_1();
        double b = ((RetrievalModelBM25) model).getb();
        double k_3 = ((RetrievalModelBM25) model).getk_3();
		double doclen = (double)(Idx.getFieldLength(field, docid));
		double avgLength = Idx.getSumOfFieldLengths(field) / (double) Idx.getDocCount(field);
        double userWeight = 1.0; // when to set it? 

		for (String stem : qstems) {
			double score = 0.0;
			
			int index = vec.indexOfStem(stem);
			if (index == -1) {
				continue;
			}
			int tf = vec.stemFreq(index);
            int df = vec.stemDf(index);



			//int df = ((QryIop) q).getDf(); //this.invertedList.df;
			double idf = Math.log10((Idx.getNumDocs() - (double)df + 0.5) / ((double)df + 0.5));

			//double idf = ((QryIop) q).getIdf();
			//double tf = (double)(((QryIop) q).docIteratorGetMatchPosting().tf);
			double tfWeight = tf*(k_1+1.0) / (tf + k_1 * (1.0-b+b*(doclen/avgLength) ) );

			score = idf * tfWeight * ( (k_3 + 1.0)*userWeight / (k_3+userWeight) );
			totalScore += score; 
		}
		return totalScore;
		/*
		double totalScore = 0;
		double k_1 = model.getk_1();
		double b = model.getb();
		double k_3 = model.getk_3();

		int N = (int)(Idx.getNumDocs()); //Idx.getDocCount(field);
		double avg_doclen = (double)(Idx.getSumOfFieldLengths(field)) / (double)N;
		int doclen = Idx.getFieldLength(field, docid);

		for (String stem : qstems) {
			int index = -1; 
			//int tf = 0;	
			//int df = 0;

			try { 
				index = vec.indexOfStem(stem);
			} catch (Exception ex) {
				continue;
			}

			if (index == -1) {
				continue;
			}
			int tf = vec.stemFreq(index);
			int df = vec.stemDf(index);
			int qtf = 1;
			double idf, tf_weight, user_weight;
			//idf = Math.log10((N - (double)df + 0.5) / ((double)df + 0.5)); //
			idf = Math.max(0, Math.log((N - df + 0.5) / (df + 0.5)));
			tf_weight = tf
					/ (double) (tf + k_1 * ((1 - b) + b * doclen / avg_doclen));
			user_weight = (k_3 + 1) * qtf / (k_3 + qtf);
			double docScore = idf * tf_weight * user_weight;
			totalScore += docScore;
		}
		*/
	}

	public double getIndriScore(RetrievalModelIndri model, int docid, String field, String[] qstems, TermVector vec) throws IOException {
		double totalScore = 1.0;
		double mu = model.getMu(); 
		double lambda = model.getLambda(); 
		boolean isMatch = false;

		int doclen = Idx.getFieldLength(field, docid);

		for (String stem : qstems) {
			int index = -1;
			//try {
			index = vec.indexOfStem(stem);
			//} catch (Exception ex) { continue; }

			int tf;
			long ctf;

			if (index == -1) {
				// if the term is not in the document
				tf = 0;
				ctf = Idx.getTotalTermFreq(field, stem);
			} else {
				// the term is in the document
				isMatch = true;
				tf = vec.stemFreq(index);
				ctf = vec.totalStemFreq(index);
			}

			double mleProb = ctf / (double)(Idx.getSumOfFieldLengths(field));
			double docScore = (1 - lambda) * ((tf + mu * mleProb) / (doclen + mu)) + lambda * mleProb;
			totalScore *= Math.pow(docScore, 1.0 / qstems.length);
		}
		return totalScore;
	}


	/*
	public double getIndriScore(RetrievalModelIndri model, Qry qx, int docid, String field) {
		double score = 1.0;
        for (int i =0; i<((QrySop) qx).args.size(); i++) {
            Qry q = qx.get(i);
			double mu = ((RetrievalModelIndri) model).getMu();
			double lambda = ((RetrievalModelIndri) model).getLambda();
			double mle = (double)(((QryIop) q).getCtf()) / (double)(Idx.getSumOfFieldLengths((field));
			double docLength = (double)(Idx.getFieldLength(((QryIop) q).field, docid));
			double tf = (double)(((QryIop) q).docIteratorGetMatchPosting().tf);
			score = indriScoreFunc(mu, lambda, tf, mle, docLength);


            if (q2.docIteratorHasMatch(model) && q2.docIteratorGetMatch() == docid) {
                score *= Math.pow(((QrySop) q2).getScore(r), 1.0/this.args.size());
            } else {
                score *= Math.pow(((QrySop) q2).getDefaultScore(r, docid), 1.0/qs.length);
            }
        }

		return score
	}
	*/

	//ArrayList<Integer>
	public LinkedHashMap<Integer, LinkedHashMap<String, Double>> getFeatureVector(String qid, String qString, HashMap<Integer, Integer> relMap, RetrievalModelBM25 model_bm25, RetrievalModelIndri model_indri, HashMap<Integer, Double> pageRankMap, ArrayList<String> featureDisable) throws Exception {		

		System.out.println("qid: "+qid);

		// get tokens
		HashMap<String, Boolean> tokenMap = new HashMap<String, Boolean>(); 
		String[] tokens = QryParser.tokenizeString(qString);
		for (int i=0; i<tokens.length; i++) {
			tokenMap.put(tokens[i], true);
		}

		String[] fields = {"body", "title", "url", "inlink"};
		ArrayList<ScoreList> r_bm25s = new ArrayList<ScoreList>(); // [fields.length];
		ArrayList<ScoreList> r_indris = new ArrayList<ScoreList>(); //[fields.length];; 
		//ArrayList<Qry> qry_bm25s = new ArrayList<Qry>();
		//ArrayList<Qry> qry_indris = new ArrayList<Qry>();
		// input is docidList
		
		for (int i=0; i<fields.length; i++) {
			System.out.println("processing ranking for field "+fields[i]);
			r_bm25s.add(QryEval.processQuery(qString, fields[i], model_bm25));
			r_indris.add(QryEval.processQuery(qString, fields[i], model_indri));
			/*
			String defaultOpBM25 = ((RetrievalModelBM25)model).defaultQrySopName ();
			String qStringBM25 = defaultOpBM25 + "(" + qString + ")";
			Qry q_bm25 = QryParser.getQuery (qStringBM25, fields[i]);
			qry_bm25s.add(q_bm25);

			String defaultOpIndri = ((RetrievalModelIndri)model).defaultQrySopName ();
			String qStringIndri = defaultOpIndri + "(" + qString + ")";
			Qry q_indri = QryParser.getQuery (qStringIndri, fields[i]);
			qry_indris.add(q_indri);
			*/
		}

		LinkedHashMap<Integer, Boolean> docMap = new LinkedHashMap<Integer, Boolean>(); 
		ArrayList<Integer> docList = new ArrayList<Integer>();
		// use bm25 body top 100 

		if (relMap == null) { // test phrase
			//r_bm25s.get(0).sort();
			ScoreList r_bm25 = r_bm25s.get(0); //QryEval.processQuery(qString, "body", model_bm25);
			r_bm25.sort();
			for (int i = 0; i < Math.min(100,r_bm25.size()); i++) {
				int docid = r_bm25.getDocid(i);
				docMap.put(docid, true); 
				docList.add(docid);
				//this.feaMap.add(docid, new HashMap<String, Double>());
			}
		} else { // train phrase
			for (int docid : relMap.keySet()) {
				docMap.put(docid, true);
				docList.add(docid);
			}
		}

		System.out.println(String.format("doclist size: %d, %d",docList.size(),docMap.size()));

		ArrayList<HashMap<Integer, Double>> scoreMap_bm25s = new ArrayList<HashMap<Integer, Double>>(); //[fields.length];
		ArrayList<HashMap<Integer, Double>> scoreMap_indris = new ArrayList<HashMap<Integer, Double>>(); // [fields.length];
		// process bm25, indri score
		for (int i=0; i<fields.length; i++) {
			scoreMap_bm25s.add(getTrimMap(r_bm25s.get(i), docMap ));
			scoreMap_indris.add(getTrimMap(r_indris.get(i), docMap ));
		}

		// start generating features... 
		for (int docid : docMap.keySet()) { 
		
			LinkedHashMap<String, Double> fMap = new LinkedHashMap<String, Double>();  
	
			// f1: Spam score for d (read from index). 
			// int spamScore = Integer.parseInt (Idx.getAttribute ("score", docid));
			if (!(featureDisable.contains("1"))) {
				int spamScore = Integer.parseInt (Idx.getAttribute("score", docid));
				fMap.put("1", (double)spamScore); 
			}

			// f2: Url depth for d(number of '/' in the rawUrl field). 
			// Hint: The raw URL is stored in your index as the rawUrl attribute. 
			if (!(featureDisable.contains("2"))) {
				String rawUrl = Idx.getAttribute ("rawUrl", docid);
				int urlScore = rawUrl.length() - rawUrl.replace("/", "").length();
				fMap.put("2", (double)urlScore); 
			}

			// f3: FromWikipedia score for d (1 if the rawUrl contains "wikipedia.org", otherwise 0).
			if (!(featureDisable.contains("3"))) {
				int wikiScore = 0;
				String rawUrl = Idx.getAttribute ("rawUrl", docid);
				if (rawUrl.toLowerCase().contains("wikipedia.org".toLowerCase())) {
					wikiScore = 1;
				}
				fMap.put("3", (double)wikiScore);  
			}

			// f4: PageRank score for d (read from file).
			if (!(featureDisable.contains("4"))) {
				double pageRankScore = pageRankMap.get(docid); 
				fMap.put("4", (double)pageRankScore); 
			}

			for (int j=0; j<fields.length; j++) {
				TermVector vec = new TermVector(docid, fields[j]);

				// f5: BM25 score for <q, dbody>.
				// f8: BM25 score for <q, dtitle>.
				// f11: BM25 score for <q, durl>.
				// f14: BM25 score for <q, dinlink>.
				if (!(featureDisable.contains(Integer.toString(4+j*3+1)))) {
					double scoreBM25 = 0.0;
					try { 
						scoreBM25 = scoreMap_bm25s.get(j).get(docid); //getDocidScore(i);
						//scoreBM25 = getBM25Score(model_bm25, docid, fields[j], tokens, vec);
					} catch (Exception ex)  { }
					fMap.put(Integer.toString(4+j*3+1), (double)scoreBM25); 
				}

				// f6: Indri score for <q, dbody>.
				// f9: Indri score for <q, dtitle>.
				// f12: Indri score for <q, durl>.
				// f15: Indri score for <q, dinlink>.
				if (!(featureDisable.contains(Integer.toString(4+j*3+2)))) {
					double scoreIndri = 0.0; 
					try { 
						scoreIndri = scoreMap_indris.get(j).get(docid);
						//scoreIndri = getIndriScore(model_indri, docid, fields[j], tokens, vec);
					} catch (Exception ex) {}

					fMap.put(Integer.toString(4+j*3+2), (double)scoreIndri); 
				}

				// f7: Term overlap score for <q, dbody>. 
				// f10: Term overlap score for <q, dtitle>.
				// f13: Term overlap score for <q, durl>.
				// Hint: Term overlap is defined as the percentage of query terms that match the document field.
				// f16: Term overlap score for <q, dinlink>.
				if (!(featureDisable.contains(Integer.toString(4+j*3+3)))) {
					/*
					TermVector vec = new TermVector(docid, fields[j]);
					int termCount = 0;
					int totalCount = 0;
					for (int k=0; k<vec.stemsLength(); k++) {
						if (tokenMap.containsKey(vec.stemString(k))){
							termCount += vec.stemFreq(k);
						}
						totalCount += vec.stemFreq(k);
					}	
					*/
					double overlapScore = getOverlapScore(tokens, vec); //0.0; 
					//if (totalCount!=0) {
					//	overlapScore = ((double)termCount)/((double)totalCount); //0;
					//}
					fMap.put(Integer.toString(4+j*3+3), overlapScore);
				}						
			}
		
			// f17: A custom feature - use your imagination.

			// f18: A custom feature - use your imagination.
			feaMap.put(docid, fMap);
		}
		return feaMap; //docList;	
	}
	
}
